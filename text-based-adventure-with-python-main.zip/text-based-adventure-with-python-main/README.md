# text-based-adventure-with-python (HOVERING VAMPIRE)
A text-based adventure game, written in Python, that starts at the foggy forest.


---------------------------------------
Step 1: set our initial values like name and answers.

---------------------------------------
Step 2: Write the story of the game and diffrent ways that the game can end.

---------------------------------------
Step 3: Write a function for each scenario and create diffrent ending with your answers.
